package myPackage;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.io.SAXReader;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;

public class ObjRepository
{
	@Test	
	public void myTest() throws FileNotFoundException, DocumentException, InterruptedException{
			File src=new File("./myFile.xml");
			FileInputStream fis=new FileInputStream(src);
			SAXReader saxReader=new SAXReader();
			Document document=saxReader.read(fis);
			WebDriver driver=new FirefoxDriver();
			driver.get("http://ndafile:8081/OnlineBankingProjectSpring/");
			driver.findElement(By.name(document.selectSingleNode("//login/uname").getText())).sendKeys("Vaibhav");
			driver.findElement(By.name(document.selectSingleNode("//login/pass").getText())).sendKeys("Jagde");
			Thread.sleep(2000);
			driver.findElement(By.name(document.selectSingleNode("//login/login_btn").getText())).click();;
			
		}
}
