package pageFactory.pages;

public class PageFactoryPage
{
	@Test
	public void verify()
	{
		WebDriver driver=new FirefoxDriver();
		driver.get("file:///D:/Users/ADM-IG-HWDLAB1B/Desktop/WorkingWithForms.html");
		
		
	}
}
