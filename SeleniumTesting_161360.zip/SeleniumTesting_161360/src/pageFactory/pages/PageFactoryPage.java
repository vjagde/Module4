package pageFactory.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;

import pageFactory.test.PageFactoryTest;




public class PageFactoryPage {
	 @Test
	  public void verify(){
	 	 WebDriver driver=new FirefoxDriver();
	 	 driver.get("http://ndafile:8081/OnlineBankingProjectSpring/");
	 	 PageFactoryTest  pageTests=PageFactory.initElements(driver,PageFactoryTest.class);
	      pageTests.testFirstPage();
	      pageTests.testLoginPage();
	      pageTests.testHomePage();
	      pageTests.testAddAccount();
	      driver.close();
	      }
}
