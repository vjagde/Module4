package pageFactory.test;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class PageFactoryTest
{
	WebDriver driver;
	String expectedFirstTitle="Online Banking System";
	String expectedFirstHeading="Online Banking Application";
	
	//login button
	@FindBy(how=How.XPATH,using="//a[contains(text(),'Admin Login')]")
	@CacheLookup
	WebElement pageTitle;

	//login button
	@FindBy(how=How.XPATH,using="div[@id='header']/img")
	@CacheLookup
	WebElement admLogin;

	public PageFactoryTest(WebDriver driver)
	{
		this.driver = driver;
	}
	
	public void testFirstPage()
	{
		System.out.println("Testing First Page...");
		WebDriverWait wait=new WebDriverWait(driver,20); //Used for explicit wait
		wait.until(ExpectedConditions.elementToBeClickable(admLogin));
		
		String actualTitle=driver.getTitle();
		if(expectedFirstTitle.contentEquals(actualTitle))
		{
			System.out.println("Test passed for page title");
		}
		else
		{
			System.out.println("Test failed for page title");
		}
		
		String actualHeading=pageTitle.getText();
		if(expectedFirstHeading.contentEquals(actualHeading))
		{
			System.out.println("Test passed for page heading");
		}
		else
		{
			System.out.println("Test failed for page heading");
		}
		
		admLogin.click();
	}
	
	public void testLoginPage()
	{
		String actualHeading
	}
	
	
}
