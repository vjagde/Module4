package pageFactory.test;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class PageFactoryTest {
WebDriver driver;
String expectedFirstTitle="Online Banking System";
String expectedSecondTitle="Login as Admin";
String expectedInvalidTxt="Invalid Credentials";
String expectedHomeTitle="Admin Home Page";
String expectedAccountHeading="Account Holder Registration";
String expectedAccBalErr="Failed to convert property value of type java.lang.String to required type java.lang.Double";

    //login button
	@FindBy(how=How.XPATH,using="//a[contains(text(),'Admin Login')]")
	@CacheLookup
	WebElement admLogin;
	
	//Username Filed
    @FindBy(name="uname")
    @CacheLookup
    WebElement lgUsrNme;
    
  //password Filed
    @FindBy(name="pass")
    @CacheLookup
    WebElement lgpasswd;
    
  //login button
  	@FindBy(how=How.XPATH,using="//tr[3]/td[2]/input")
  	@CacheLookup
  	WebElement lgnBtn;

  	 //login button
  	@FindBy(how=How.XPATH,using="//div[@id='header']/div/h3")
  	@CacheLookup
  	WebElement invalidCredTxt;
  	
  	 //login button
  	@FindBy(how=How.LINK_TEXT,using="Add New Account")
  	@CacheLookup
  	WebElement addAccLnk;
  	
  //Heading
  	@FindBy(how=How.CSS,using="h2")
  	@CacheLookup
  	WebElement accheading;
  	
  //Account Holder Address
    @FindBy(id="customer.customerAddress")
    WebElement accAddr;
    
  //Account Holder Name
    @FindBy(id="customer.customerName")
    WebElement accName;
    
  //Account Holder Pan
    @FindBy(id="customer.customerPancard")
    WebElement accPan;

  //Account Holder email
    @FindBy(id="customer.customerEmail")
    WebElement accEmail;
    
  //finding element Register
  	@FindBy(how=How.XPATH,using="//input[@value='Register']")
  	WebElement accReg;
  	
  //Account Pan Err
    @FindBy(id="customer.customerPancard.errors")
    WebElement accPanErr;
 
    //Account Holder email Err
    @FindBy(id="customer.customerEmail.errors")
    WebElement accEmailErr;
    
    //Account Holder email
    @FindBy(id="account.accountType")
    Select accType;
    
  //Account Holder Bal
    @FindBy(id="account.accountBalance")
    WebElement accBal;
    
  //Account Holder Bal
    @FindBy(id="account.accountBalance.errors")
    @CacheLookup
    WebElement accBalErr;
  
  //Account Holder Opening date
    @FindBy(id="account.accountOpenDate")
    @CacheLookup
    WebElement accDate;
  
  //Account Holder secret question
    @FindBy(id="user.userTransPassword")
    @CacheLookup
    Select accScrQ;
 
    //Account Holder Enter Secret Ans
    @FindBy(id="account.accountOpenDate")
    @CacheLookup
    WebElement accScrA;
	public PageFactoryTest(WebDriver driver) {
		this.driver = driver;
	}


public void testFirstPage(){
	System.out.println("Starting first Test....");
	WebDriverWait wait = new WebDriverWait(driver, 40);//Explicit wait
	wait.until(ExpectedConditions.elementToBeClickable(admLogin));
	
	//Checking Title
	String actualTitle=driver.getTitle();
	if(expectedFirstTitle.contentEquals(actualTitle)){
		System.out.println("Test Passed for Page Title");
	}else{
		System.out.println("Test Not Passed for Page Title,Actual="+actualTitle);
	}	
	
	//Clicking on Admin Login
	admLogin.click();
}

public void testLoginPage(){
	driver.manage().timeouts().implicitlyWait(20,TimeUnit.SECONDS);//implicit wait
	//Checking for correct Page
	String actualLoginTitle=driver.getTitle();
	if(expectedSecondTitle.contentEquals(actualLoginTitle)){
		System.out.println("Test Passed for Login Page Title");
	}else{
		System.out.println("Test Not Passed for Page Title,Actual="+actualLoginTitle);
	}
	
	
	lgUsrNme.sendKeys("Admin");//Entering Username
	String EnterdUsrname="Admin";
	if(EnterdUsrname.contentEquals(lgUsrNme.getAttribute("value"))){
		System.out.println("Test Passed for Enterd username");
	}else{
		System.out.println("Test Not Passed for Enterd username,Actual="+actualLoginTitle);
	}
	
	
	lgpasswd.sendKeys("Admin123");//Entering Password
	String EnterdPwd="Admin123";
	if(EnterdPwd.contentEquals(lgpasswd.getAttribute("value"))){
		System.out.println("Test Passed for Entered Password");
	}else{
		System.out.println("Test Not Passed for Enterd Password,Actual="+actualLoginTitle);
	}
	lgnBtn.click();
}

public void testHomePage(){
	driver.manage().timeouts().implicitlyWait(20,TimeUnit.SECONDS);//Implicit Wait
	//Test for Title
	if(expectedHomeTitle.contentEquals(driver.getTitle())){
		System.out.println("Test Passed for Home Page Tile");
	}else{
		System.out.println("Test Not Passed for Home Page Tile");
	}
	//Explicit Wait
	WebDriverWait wait = new WebDriverWait(driver, 40);//Explicit wait
	wait.until(ExpectedConditions.elementToBeClickable(addAccLnk));
	
	//Clicking add Account Link
	addAccLnk.click();
	
}

public void testAddAccount(){
	driver.manage().timeouts().implicitlyWait(20,TimeUnit.SECONDS);//Implicit Wait
	if(expectedAccountHeading.contentEquals(accheading.getText())){
		System.out.println("Test Passed for Home Page Tile");
	}else{
		System.out.println("Test Not Passed for Home Page Tile,Actual="+accheading.getText());
	}
	accName.sendKeys("Vaibhav");
	accAddr.sendKeys("Dombivli");
	accPan.sendKeys("PAN");
	accReg.click();
	//Verifing 10 pan Chars
	if("Enter Maximum 10 Characters".contentEquals(accPanErr.getText())){
		System.out.println("Test Passed for Pan Maximum 10 Characters");
	}else{
		System.out.println("Test Not Passed for Pan Maximum 10 Characters");
	}
	accPan.clear();
	accPan.sendKeys("VJAGDE1234");
	//Verify Email
	accEmail.sendKeys("Wrong.Format");
	accReg.click();
	if("Please Enter Valid Email".contentEquals(accEmailErr.getText())){
		System.out.println("Test Passed for Enter Valid Email");
	}else{
		System.out.println("Test Failed for Enter Valid Email");
	}
	accEmail.sendKeys("adesh.shetty@capgemini.com");
	//accType.selectByValue("Current");
	
	//verifying only digit in balance
	accBal.sendKeys("Abc");
	accReg.click();
	if(accBalErr.getText().contains(expectedAccBalErr)){
		System.out.println("Test Passed for Only Digit BAl");
	}else{
		System.out.println("Test Failed for only Digit Bal");
	}
	//Verifying Current opening Date
	if(accDate.getAttribute("value").contentEquals("2018-11-29")){
		System.out.println("Test Passed For opening current Date");
	}else{
		System.out.println("Test Failed For current Date");
	}
	//Selecting User Question
	//accScrQ.selectByValue("What is your birth place?");
	//Enter Secrect Answer
	accScrA.sendKeys("Dombivli");
	accReg.click();
}

}
